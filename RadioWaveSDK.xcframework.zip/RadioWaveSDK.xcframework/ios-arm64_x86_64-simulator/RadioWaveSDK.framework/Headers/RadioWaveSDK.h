#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class RWSDKKoin_coreKoin, RWSDKKmmLogger, RWSDKUserResponse, RWSDKFirebase_authAuthCredential, RWSDKLocalType, RWSDKAppInfo, RWSDKUserUi, RWSDKUser, RWSDKProfile, RWSDKRadioWaveDatabaseQueries, RWSDKRadioWaveDatabaseCompanion, RWSDKProfileAdapter, RWSDKKotlinUnit, RWSDKRuntimeTransacterTransaction, RWSDKKotlinThrowable, RWSDKRuntimeBaseTransacterImpl, RWSDKRuntimeTransacterImpl, RWSDKRuntimeQuery<__covariant RowType>, RWSDKRuntimeExecutableQuery<__covariant RowType>, RWSDKKotlinx_coroutines_coreCoroutineDispatcher, RWSDKKotlinArray<T>, RWSDKKotlinException, RWSDKErrorResponseCompanion, RWSDKErrorResponse, RWSDKServerResponseException, RWSDKKotlinEnumCompanion, RWSDKKotlinEnum<E>, RWSDKFieldsCompanion, RWSDKFields, RWSDKPostUrlCompanion, RWSDKPostUrl, RWSDKRemoteTypeCompanion, RWSDKRemoteType, RWSDKUserCompanion, RWSDKUserResponseCompanion, RWSDKPictureData, RWSDKType, RWSDKUiError, RWSDKAllowedCharactersError, RWSDKEmptyValueError, RWSDKInvalidEmailError, RWSDKMaximumSizeFieldError, RWSDKMinimumSizeFieldError, RWSDKNotNullObjectError, RWSDKSameValueError, RWSDKEmailValidator, RWSDKNameValidator, RWSDKPasswordValidator, RWSDKSamePasswordValidator, RWSDKKoin_coreModule, RWSDKKoin_coreScope, RWSDKKoin_coreParametersHolder, RWSDKKotlinLazyThreadSafetyMode, RWSDKKoin_coreLogger, RWSDKKoin_coreExtensionManager, RWSDKKoin_coreInstanceRegistry, RWSDKKoin_corePropertyRegistry, RWSDKKoin_coreScopeRegistry, RWSDKKotlinRuntimeException, RWSDKKotlinIllegalStateException, FIRAuthCredential, RWSDKRuntimeAfterVersion, RWSDKKotlinAbstractCoroutineContextElement, RWSDKKotlinx_coroutines_coreCoroutineDispatcherKey, RWSDKKoin_coreKoinDefinition<R>, RWSDKKoin_coreInstanceFactory<T>, RWSDKKoin_coreSingleInstanceFactory<T>, RWSDKKoin_coreScopeDSL, RWSDKKoin_coreLockable, RWSDKStately_concurrencyThreadLocalRef<T>, RWSDKKoin_coreLevel, RWSDKKoin_coreScopeRegistryCompanion, RWSDKKotlinByteArray, RWSDKKotlinAbstractCoroutineContextKey<B, E>, RWSDKKotlinx_serialization_coreSerializersModule, RWSDKKotlinx_serialization_coreSerialKind, RWSDKKotlinNothing, RWSDKKoin_coreBeanDefinition<T>, RWSDKKoin_coreInstanceFactoryCompanion, RWSDKKoin_coreInstanceContext, RWSDKKotlinByteIterator, RWSDKKoin_coreKind, RWSDKKoin_coreCallbacks<T>;

@protocol RWSDKPlatform, RWSDKKoin_coreKoinComponent, RWSDKKotlinx_coroutines_coreFlow, RWSDKRuntimeSqlDriver, RWSDKRuntimeColumnAdapter, RWSDKRuntimeTransactionWithoutReturn, RWSDKRuntimeTransactionWithReturn, RWSDKRuntimeTransacterBase, RWSDKRuntimeTransacter, RWSDKRadioWaveDatabase, RWSDKRuntimeSqlSchema, RWSDKAuthRepository, RWSDKDataStoreApi, RWSDKUserRepository, RWSDKKotlinx_serialization_coreKSerializer, RWSDKKotlinComparable, RWSDKUiErrorValidator, RWSDKDatastore_coreDataStore, RWSDKKoin_coreKoinScopeComponent, RWSDKKoin_coreQualifier, RWSDKKotlinKClass, RWSDKKotlinLazy, RWSDKKotlinx_coroutines_coreFlowCollector, RWSDKRuntimeQueryListener, RWSDKRuntimeQueryResult, RWSDKRuntimeSqlPreparedStatement, RWSDKRuntimeSqlCursor, RWSDKRuntimeCloseable, RWSDKRuntimeTransactionCallbacks, RWSDKKotlinCoroutineContextKey, RWSDKKotlinCoroutineContextElement, RWSDKKotlinCoroutineContext, RWSDKKotlinContinuation, RWSDKKotlinContinuationInterceptor, RWSDKKotlinx_coroutines_coreRunnable, RWSDKKotlinIterator, RWSDKKotlinx_serialization_coreEncoder, RWSDKKotlinx_serialization_coreSerialDescriptor, RWSDKKotlinx_serialization_coreSerializationStrategy, RWSDKKotlinx_serialization_coreDecoder, RWSDKKotlinx_serialization_coreDeserializationStrategy, RWSDKKotlinSuspendFunction1, RWSDKKoin_coreScopeCallback, RWSDKKotlinKDeclarationContainer, RWSDKKotlinKAnnotatedElement, RWSDKKotlinKClassifier, RWSDKKoin_coreKoinExtension, RWSDKKotlinx_serialization_coreCompositeEncoder, RWSDKKotlinAnnotation, RWSDKKotlinx_serialization_coreCompositeDecoder, RWSDKKotlinFunction, RWSDKKotlinx_serialization_coreSerializersModuleCollector;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface RWSDKBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface RWSDKBase (RWSDKBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface RWSDKMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface RWSDKMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorRWSDKKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface RWSDKNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface RWSDKByte : RWSDKNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface RWSDKUByte : RWSDKNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface RWSDKShort : RWSDKNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface RWSDKUShort : RWSDKNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface RWSDKInt : RWSDKNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface RWSDKUInt : RWSDKNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface RWSDKLong : RWSDKNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface RWSDKULong : RWSDKNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface RWSDKFloat : RWSDKNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface RWSDKDouble : RWSDKNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface RWSDKBoolean : RWSDKNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((swift_name("Platform")))
@protocol RWSDKPlatform
@required
- (int32_t)hexToIntHex:(NSString *)hex __attribute__((swift_name("hexToInt(hex:)")));
- (NSString *)intToHexColor:(int32_t)color __attribute__((swift_name("intToHex(color:)")));
@property (readonly) NSString *langTag __attribute__((swift_name("langTag")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IOSPlatform")))
@interface RWSDKIOSPlatform : RWSDKBase <RWSDKPlatform>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (int32_t)hexToIntHex:(NSString *)hex __attribute__((swift_name("hexToInt(hex:)")));
- (NSString *)intToHexColor:(int32_t)color __attribute__((swift_name("intToHex(color:)")));
@property (readonly) NSString *langTag __attribute__((swift_name("langTag")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("Koin_coreKoinComponent")))
@protocol RWSDKKoin_coreKoinComponent
@required
- (RWSDKKoin_coreKoin *)getKoin __attribute__((swift_name("getKoin()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SetupDi")))
@interface RWSDKSetupDi : RWSDKBase <RWSDKKoin_coreKoinComponent>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KmmLogger")))
@interface RWSDKKmmLogger : RWSDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)kmmLogger __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) RWSDKKmmLogger *shared __attribute__((swift_name("shared")));
- (void)setUpLoggerIsDebugEnabled:(BOOL)isDebugEnabled __attribute__((swift_name("setUpLogger(isDebugEnabled:)")));
@end

__attribute__((swift_name("AuthRepository")))
@protocol RWSDKAuthRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)facebookLoginContext:(id _Nullable)context completionHandler:(void (^)(RWSDKUserResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("facebookLogin(context:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)facebookRegisterContext:(id _Nullable)context completionHandler:(void (^)(RWSDKUserResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("facebookRegister(context:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)forgotPasswordEmail:(NSString *)email completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("forgotPassword(email:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)googleLoginIdToken:(NSString *)idToken completionHandler:(void (^)(RWSDKUserResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("googleLogin(idToken:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)googleRegisterIdToken:(NSString *)idToken completionHandler:(void (^)(RWSDKUserResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("googleRegister(idToken:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)isEmailVerifiedWithCompletionHandler:(void (^)(RWSDKBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("isEmailVerified(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)loginWithCredentialsEmail:(NSString *)email password:(NSString *)password completionHandler:(void (^)(RWSDKUserResponse * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("loginWithCredentials(email:password:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)registerUserCredentialsEmail:(NSString *)email password:(NSString *)password completionHandler:(void (^)(RWSDKUserResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("registerUserCredentials(email:password:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)sendEmailVerificationWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("sendEmailVerification(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)tokenWithCompletionHandler:(void (^)(id<RWSDKKotlinx_coroutines_coreFlow> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("token(completionHandler:)")));
@end

__attribute__((swift_name("AuthDataSource")))
@protocol RWSDKAuthDataSource
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)facebookLoginContext:(id _Nullable)context completionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("facebookLogin(context:completionHandler_:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)forgotPasswordEmail:(NSString *)email completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("forgotPassword(email:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)googleLoginIdToken:(NSString *)idToken completionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("googleLogin(idToken:completionHandler_:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)isEmailVerifiedWithCompletionHandler:(void (^)(RWSDKBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("isEmailVerified(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)loginWithCredentialsEmail:(NSString *)email password:(NSString *)password completionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("loginWithCredentials(email:password:completionHandler_:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)registerUserCredentialsEmail:(NSString *)email password:(NSString *)password completionHandler_:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("registerUserCredentials(email:password:completionHandler_:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)sendEmailVerificationWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("sendEmailVerification(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)tokenWithCompletionHandler:(void (^)(id<RWSDKKotlinx_coroutines_coreFlow> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("token(completionHandler:)")));
@end

__attribute__((swift_name("AuthApi")))
@protocol RWSDKAuthApi
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)facebookLoginContext:(id _Nullable)context completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("facebookLogin(context:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)forgotPasswordEmail:(NSString *)email completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("forgotPassword(email:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)isEmailVerifiedWithCompletionHandler:(void (^)(RWSDKBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("isEmailVerified(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)loginWithCredentialsEmail:(NSString *)email password:(NSString *)password completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("loginWithCredentials(email:password:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)processGoogleLoginIdToken:(NSString *)idToken completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("processGoogleLogin(idToken:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)registerUserCredentialsEmail:(NSString *)email password:(NSString *)password completionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("registerUserCredentials(email:password:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)tokenWithCompletionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("token(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)verifyEmailWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("verifyEmail(completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FacebookSdk")))
@interface RWSDKFacebookSdk : RWSDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)loginContext:(id _Nullable)context completionHandler:(void (^)(RWSDKFirebase_authAuthCredential * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("login(context:completionHandler:)")));
@property (readonly) id<RWSDKKotlinx_coroutines_coreFlow> authCredential __attribute__((swift_name("authCredential")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GoogleSdk")))
@interface RWSDKGoogleSdk : RWSDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)processGoogleIdToken:(NSString *)googleIdToken completionHandler:(void (^)(RWSDKFirebase_authAuthCredential * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("process(googleIdToken:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DatabaseDriverFactory")))
@interface RWSDKDatabaseDriverFactory : RWSDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<RWSDKRuntimeSqlDriver>)createDriver __attribute__((swift_name("createDriver()")));
@end

__attribute__((swift_name("RuntimeColumnAdapter")))
@protocol RWSDKRuntimeColumnAdapter
@required
- (id)decodeDatabaseValue:(id _Nullable)databaseValue __attribute__((swift_name("decode(databaseValue:)")));
- (id _Nullable)encodeValue:(id)value __attribute__((swift_name("encode(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TypeColumnAdapter")))
@interface RWSDKTypeColumnAdapter : RWSDKBase <RWSDKRuntimeColumnAdapter>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (RWSDKLocalType *)decodeDatabaseValue:(NSString *)databaseValue __attribute__((swift_name("decode(databaseValue:)")));
- (NSString *)encodeValue:(RWSDKLocalType *)value __attribute__((swift_name("encode(value:)")));
@end

__attribute__((swift_name("DataStoreApi")))
@protocol RWSDKDataStoreApi
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)saveSettings:(RWSDKAppInfo *)settings completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("save(settings:completionHandler:)")));
@property (readonly) id<RWSDKKotlinx_coroutines_coreFlow> settings __attribute__((swift_name("settings")));
@end

__attribute__((swift_name("UserRepository")))
@protocol RWSDKUserRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getUserWithCompletionHandler:(void (^)(RWSDKUserUi * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getUser(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateUserUser:(RWSDKUser *)user completionHandler:(void (^)(RWSDKUserUi * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateUser(user:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateUserPhotoWithCompletionHandler:(void (^)(RWSDKUserUi * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateUserPhoto(completionHandler:)")));
@end

__attribute__((swift_name("UserDataSource")))
@protocol RWSDKUserDataSource
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getUserWithCompletionHandler:(void (^)(RWSDKUserResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getUser(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)registerUserWithCompletionHandler:(void (^)(RWSDKUserResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("registerUser(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateUserUser:(RWSDKUser *)user completionHandler:(void (^)(RWSDKUserResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateUser(user:completionHandler:)")));
@end

__attribute__((swift_name("UserDao")))
@protocol RWSDKUserDao
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)deleteProfileEmail:(NSString *)email completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("deleteProfile(email:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getProfileByEmailEmail:(NSString * _Nullable)email completionHandler:(void (^)(RWSDKProfile * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("getProfileByEmail(email:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)insertProfile:(RWSDKProfile *)profile completionHandler:(void (^)(RWSDKProfile * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("insert(profile:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateProfileProfile:(RWSDKProfile *)profile completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("updateProfile(profile:completionHandler:)")));
@end

__attribute__((swift_name("UserApi")))
@protocol RWSDKUserApi
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getUserWithCompletionHandler:(void (^)(RWSDKUserResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getUser(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)registerUserWithCompletionHandler:(void (^)(RWSDKUserResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("registerUser(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateUserUser:(RWSDKUser *)user completionHandler:(void (^)(RWSDKUserResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("updateUser(user:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Profile")))
@interface RWSDKProfile : RWSDKBase
- (instancetype)initWithEmail:(NSString *)email name:(NSString * _Nullable)name notificationsEnabled:(BOOL)notificationsEnabled profilePicture:(NSString * _Nullable)profilePicture pushId:(NSString * _Nullable)pushId type:(RWSDKLocalType *)type __attribute__((swift_name("init(email:name:notificationsEnabled:profilePicture:pushId:type:)"))) __attribute__((objc_designated_initializer));
- (RWSDKProfile *)doCopyEmail:(NSString *)email name:(NSString * _Nullable)name notificationsEnabled:(BOOL)notificationsEnabled profilePicture:(NSString * _Nullable)profilePicture pushId:(NSString * _Nullable)pushId type:(RWSDKLocalType *)type __attribute__((swift_name("doCopy(email:name:notificationsEnabled:profilePicture:pushId:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) BOOL notificationsEnabled __attribute__((swift_name("notificationsEnabled")));
@property (readonly) NSString * _Nullable profilePicture __attribute__((swift_name("profilePicture")));
@property (readonly) NSString * _Nullable pushId __attribute__((swift_name("pushId")));
@property (readonly) RWSDKLocalType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Profile.Adapter")))
@interface RWSDKProfileAdapter : RWSDKBase
- (instancetype)initWithTypeAdapter:(id<RWSDKRuntimeColumnAdapter>)typeAdapter __attribute__((swift_name("init(typeAdapter:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<RWSDKRuntimeColumnAdapter> typeAdapter __attribute__((swift_name("typeAdapter")));
@end

__attribute__((swift_name("RuntimeTransacterBase")))
@protocol RWSDKRuntimeTransacterBase
@required
@end

__attribute__((swift_name("RuntimeTransacter")))
@protocol RWSDKRuntimeTransacter <RWSDKRuntimeTransacterBase>
@required
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(id<RWSDKRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
- (id _Nullable)transactionWithResultNoEnclosing:(BOOL)noEnclosing bodyWithReturn:(id _Nullable (^)(id<RWSDKRuntimeTransactionWithReturn>))bodyWithReturn __attribute__((swift_name("transactionWithResult(noEnclosing:bodyWithReturn:)")));
@end

__attribute__((swift_name("RadioWaveDatabase")))
@protocol RWSDKRadioWaveDatabase <RWSDKRuntimeTransacter>
@required
@property (readonly) RWSDKRadioWaveDatabaseQueries *radioWaveDatabaseQueries __attribute__((swift_name("radioWaveDatabaseQueries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RadioWaveDatabaseCompanion")))
@interface RWSDKRadioWaveDatabaseCompanion : RWSDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) RWSDKRadioWaveDatabaseCompanion *shared __attribute__((swift_name("shared")));
- (id<RWSDKRadioWaveDatabase>)invokeDriver:(id<RWSDKRuntimeSqlDriver>)driver ProfileAdapter:(RWSDKProfileAdapter *)ProfileAdapter __attribute__((swift_name("invoke(driver:ProfileAdapter:)")));
@property (readonly) id<RWSDKRuntimeSqlSchema> Schema __attribute__((swift_name("Schema")));
@end

__attribute__((swift_name("RuntimeBaseTransacterImpl")))
@interface RWSDKRuntimeBaseTransacterImpl : RWSDKBase
- (instancetype)initWithDriver:(id<RWSDKRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (NSString *)createArgumentsCount:(int32_t)count __attribute__((swift_name("createArguments(count:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)notifyQueriesIdentifier:(int32_t)identifier tableProvider:(void (^)(RWSDKKotlinUnit *(^)(NSString *)))tableProvider __attribute__((swift_name("notifyQueries(identifier:tableProvider:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id _Nullable)postTransactionCleanupTransaction:(RWSDKRuntimeTransacterTransaction *)transaction enclosing:(RWSDKRuntimeTransacterTransaction * _Nullable)enclosing thrownException:(RWSDKKotlinThrowable * _Nullable)thrownException returnValue:(id _Nullable)returnValue __attribute__((swift_name("postTransactionCleanup(transaction:enclosing:thrownException:returnValue:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<RWSDKRuntimeSqlDriver> driver __attribute__((swift_name("driver")));
@end

__attribute__((swift_name("RuntimeTransacterImpl")))
@interface RWSDKRuntimeTransacterImpl : RWSDKRuntimeBaseTransacterImpl <RWSDKRuntimeTransacter>
- (instancetype)initWithDriver:(id<RWSDKRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(id<RWSDKRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
- (id _Nullable)transactionWithResultNoEnclosing:(BOOL)noEnclosing bodyWithReturn:(id _Nullable (^)(id<RWSDKRuntimeTransactionWithReturn>))bodyWithReturn __attribute__((swift_name("transactionWithResult(noEnclosing:bodyWithReturn:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RadioWaveDatabaseQueries")))
@interface RWSDKRadioWaveDatabaseQueries : RWSDKRuntimeTransacterImpl
- (instancetype)initWithDriver:(id<RWSDKRuntimeSqlDriver>)driver ProfileAdapter:(RWSDKProfileAdapter *)ProfileAdapter __attribute__((swift_name("init(driver:ProfileAdapter:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithDriver:(id<RWSDKRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (void)deleteProfileEmail:(NSString *)email __attribute__((swift_name("deleteProfile(email:)")));
- (RWSDKRuntimeQuery<RWSDKProfile *> *)getProfileValue_:(NSString *)value_ __attribute__((swift_name("getProfile(value_:)")));
- (RWSDKRuntimeQuery<id> *)getProfileValue:(NSString *)value mapper:(id (^)(NSString *, NSString * _Nullable, RWSDKBoolean *, NSString * _Nullable, NSString * _Nullable, RWSDKLocalType *))mapper __attribute__((swift_name("getProfile(value:mapper:)")));
- (RWSDKRuntimeQuery<RWSDKProfile *> *)getProfileSingle __attribute__((swift_name("getProfileSingle()")));
- (RWSDKRuntimeQuery<id> *)getProfileSingleMapper:(id (^)(NSString *, NSString * _Nullable, RWSDKBoolean *, NSString * _Nullable, NSString * _Nullable, RWSDKLocalType *))mapper __attribute__((swift_name("getProfileSingle(mapper:)")));
- (void)insertProfileEmail:(NSString *)email name:(NSString * _Nullable)name notificationsEnabled:(BOOL)notificationsEnabled profilePicture:(NSString * _Nullable)profilePicture pushId:(NSString * _Nullable)pushId type:(RWSDKLocalType *)type __attribute__((swift_name("insertProfile(email:name:notificationsEnabled:profilePicture:pushId:type:)")));
- (RWSDKRuntimeExecutableQuery<RWSDKLong *> *)selectLastInsertedRowId __attribute__((swift_name("selectLastInsertedRowId()")));
- (void)updateProfileEmail:(NSString *)email name:(NSString * _Nullable)name notificationsEnabled:(BOOL)notificationsEnabled profilePicture:(NSString * _Nullable)profilePicture pushId:(NSString * _Nullable)pushId type:(RWSDKLocalType *)type email_:(NSString *)email_ __attribute__((swift_name("updateProfile(email:name:notificationsEnabled:profilePicture:pushId:type:email_:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FacebookLoginUseCase")))
@interface RWSDKFacebookLoginUseCase : RWSDKBase
- (instancetype)initWithAuthRepository:(id<RWSDKAuthRepository>)authRepository dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(authRepository:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invokeContext:(id _Nullable)context __attribute__((swift_name("invoke(context:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("FacebookRegisterUseCase")))
@interface RWSDKFacebookRegisterUseCase : RWSDKBase
- (instancetype)initWithAuthRepository:(id<RWSDKAuthRepository>)authRepository dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(authRepository:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invokeContext:(id _Nullable)context __attribute__((swift_name("invoke(context:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ForgotPasswordUseCase")))
@interface RWSDKForgotPasswordUseCase : RWSDKBase
- (instancetype)initWithAuthRepository:(id<RWSDKAuthRepository>)authRepository dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(authRepository:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invokeEmail:(NSString *)email __attribute__((swift_name("invoke(email:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GoogleLoginUseCase")))
@interface RWSDKGoogleLoginUseCase : RWSDKBase
- (instancetype)initWithAuthRepository:(id<RWSDKAuthRepository>)authRepository dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(authRepository:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invokeIdToken:(NSString * _Nullable)idToken __attribute__((swift_name("invoke(idToken:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GoogleRegisterUseCase")))
@interface RWSDKGoogleRegisterUseCase : RWSDKBase
- (instancetype)initWithAuthRepository:(id<RWSDKAuthRepository>)authRepository dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(authRepository:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invokeIdToken:(NSString * _Nullable)idToken __attribute__((swift_name("invoke(idToken:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("IsEmailVerifiedUseCase")))
@interface RWSDKIsEmailVerifiedUseCase : RWSDKBase
- (instancetype)initWithAuthRepository:(id<RWSDKAuthRepository>)authRepository dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(authRepository:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invoke __attribute__((swift_name("invoke()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoginEmailUseCase")))
@interface RWSDKLoginEmailUseCase : RWSDKBase
- (instancetype)initWithAuthRepository:(id<RWSDKAuthRepository>)authRepository dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(authRepository:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invokeEmail:(NSString *)email password:(NSString *)password __attribute__((swift_name("invoke(email:password:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RegisterEmailUseCase")))
@interface RWSDKRegisterEmailUseCase : RWSDKBase
- (instancetype)initWithAuthRepository:(id<RWSDKAuthRepository>)authRepository dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(authRepository:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invokeEmail:(NSString *)email password:(NSString *)password __attribute__((swift_name("invoke(email:password:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SendEmailVerificationUseCase")))
@interface RWSDKSendEmailVerificationUseCase : RWSDKBase
- (instancetype)initWithAuthRepository:(id<RWSDKAuthRepository>)authRepository dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(authRepository:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invoke __attribute__((swift_name("invoke()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenUseCase")))
@interface RWSDKTokenUseCase : RWSDKBase
- (instancetype)initWithAuthRepository:(id<RWSDKAuthRepository>)authRepository dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(authRepository:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invoke __attribute__((swift_name("invoke()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PreferencesUseCase")))
@interface RWSDKPreferencesUseCase : RWSDKBase
- (instancetype)initWithApi:(id<RWSDKDataStoreApi>)api dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(api:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invoke __attribute__((swift_name("invoke()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SavePreferencesUseCase")))
@interface RWSDKSavePreferencesUseCase : RWSDKBase
- (instancetype)initWithApi:(id<RWSDKDataStoreApi>)api dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(api:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invokeAppInfo:(RWSDKAppInfo *)appInfo __attribute__((swift_name("invoke(appInfo:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserInfoUpdateUseCase")))
@interface RWSDKUserInfoUpdateUseCase : RWSDKBase
- (instancetype)initWithUserRepository:(id<RWSDKUserRepository>)userRepository dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(userRepository:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invokeUserUi:(RWSDKUserUi *)userUi __attribute__((swift_name("invoke(userUi:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserInfoUseCase")))
@interface RWSDKUserInfoUseCase : RWSDKBase
- (instancetype)initWithUserRepository:(id<RWSDKUserRepository>)userRepository dispatcher:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)dispatcher __attribute__((swift_name("init(userRepository:dispatcher:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKKotlinx_coroutines_coreFlow>)invoke __attribute__((swift_name("invoke()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AppInfo")))
@interface RWSDKAppInfo : RWSDKBase
- (instancetype)initWithIsFirstTime:(BOOL)isFirstTime token:(NSString * _Nullable)token localType:(RWSDKLocalType *)localType __attribute__((swift_name("init(isFirstTime:token:localType:)"))) __attribute__((objc_designated_initializer));
- (RWSDKAppInfo *)doCopyIsFirstTime:(BOOL)isFirstTime token:(NSString * _Nullable)token localType:(RWSDKLocalType *)localType __attribute__((swift_name("doCopy(isFirstTime:token:localType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isFirstTime __attribute__((swift_name("isFirstTime")));
@property (readonly) RWSDKLocalType *localType __attribute__((swift_name("localType")));
@property (readonly) NSString * _Nullable token __attribute__((swift_name("token")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface RWSDKKotlinThrowable : RWSDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (RWSDKKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) RWSDKKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface RWSDKKotlinException : RWSDKKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BadResponseException")))
@interface RWSDKBadResponseException : RWSDKKotlinException
- (instancetype)initWithException:(RWSDKKotlinException *)exception __attribute__((swift_name("init(exception:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EmailVerificationNoSentException")))
@interface RWSDKEmailVerificationNoSentException : RWSDKKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ErrorResponse")))
@interface RWSDKErrorResponse : RWSDKBase
- (instancetype)initWithCode:(int32_t)code message:(NSString *)message __attribute__((swift_name("init(code:message:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) RWSDKErrorResponseCompanion *companion __attribute__((swift_name("companion")));
- (RWSDKErrorResponse *)doCopyCode:(int32_t)code message:(NSString *)message __attribute__((swift_name("doCopy(code:message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="code")
*/
@property (readonly) int32_t code __attribute__((swift_name("code")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ErrorResponse.Companion")))
@interface RWSDKErrorResponseCompanion : RWSDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) RWSDKErrorResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<RWSDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MissingException")))
@interface RWSDKMissingException : RWSDKKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NoSessionException")))
@interface RWSDKNoSessionException : RWSDKKotlinException
- (instancetype)initWithException:(RWSDKKotlinException * _Nullable)exception __attribute__((swift_name("init(exception:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ServerResponseException")))
@interface RWSDKServerResponseException : RWSDKKotlinException
- (instancetype)initWithHttpCode:(int32_t)httpCode errorResponse:(RWSDKErrorResponse *)errorResponse __attribute__((swift_name("init(httpCode:errorResponse:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (RWSDKServerResponseException *)doCopyHttpCode:(int32_t)httpCode errorResponse:(RWSDKErrorResponse *)errorResponse __attribute__((swift_name("doCopy(httpCode:errorResponse:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) RWSDKErrorResponse *errorResponse __attribute__((swift_name("errorResponse")));
@property (readonly) int32_t httpCode __attribute__((swift_name("httpCode")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol RWSDKKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface RWSDKKotlinEnum<E> : RWSDKBase <RWSDKKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) RWSDKKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocalType")))
@interface RWSDKLocalType : RWSDKKotlinEnum<RWSDKLocalType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) RWSDKLocalType *regular __attribute__((swift_name("regular")));
@property (class, readonly) RWSDKLocalType *premium __attribute__((swift_name("premium")));
+ (RWSDKKotlinArray<RWSDKLocalType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<RWSDKLocalType *> *entries __attribute__((swift_name("entries")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Fields")))
@interface RWSDKFields : RWSDKBase
- (instancetype)initWithAwsAccessKeyId:(NSString *)awsAccessKeyId key:(NSString *)key policy:(NSString *)policy signature:(NSString *)signature __attribute__((swift_name("init(awsAccessKeyId:key:policy:signature:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) RWSDKFieldsCompanion *companion __attribute__((swift_name("companion")));
- (RWSDKFields *)doCopyAwsAccessKeyId:(NSString *)awsAccessKeyId key:(NSString *)key policy:(NSString *)policy signature:(NSString *)signature __attribute__((swift_name("doCopy(awsAccessKeyId:key:policy:signature:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="AWSAccessKeyId")
*/
@property (readonly) NSString *awsAccessKeyId __attribute__((swift_name("awsAccessKeyId")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="key")
*/
@property (readonly) NSString *key __attribute__((swift_name("key")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="policy")
*/
@property (readonly) NSString *policy __attribute__((swift_name("policy")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="signature")
*/
@property (readonly) NSString *signature __attribute__((swift_name("signature")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Fields.Companion")))
@interface RWSDKFieldsCompanion : RWSDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) RWSDKFieldsCompanion *shared __attribute__((swift_name("shared")));
- (id<RWSDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PostUrl")))
@interface RWSDKPostUrl : RWSDKBase
- (instancetype)initWithFields:(RWSDKFields *)fields url:(NSString *)url __attribute__((swift_name("init(fields:url:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) RWSDKPostUrlCompanion *companion __attribute__((swift_name("companion")));
- (RWSDKPostUrl *)doCopyFields:(RWSDKFields *)fields url:(NSString *)url __attribute__((swift_name("doCopy(fields:url:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="fields")
*/
@property (readonly) RWSDKFields *fields __attribute__((swift_name("fields")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="url")
*/
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PostUrl.Companion")))
@interface RWSDKPostUrlCompanion : RWSDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) RWSDKPostUrlCompanion *shared __attribute__((swift_name("shared")));
- (id<RWSDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RemoteType")))
@interface RWSDKRemoteType : RWSDKKotlinEnum<RWSDKRemoteType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) RWSDKRemoteTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) RWSDKRemoteType *regular __attribute__((swift_name("regular")));
@property (class, readonly) RWSDKRemoteType *premium __attribute__((swift_name("premium")));
+ (RWSDKKotlinArray<RWSDKRemoteType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<RWSDKRemoteType *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RemoteType.Companion")))
@interface RWSDKRemoteTypeCompanion : RWSDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) RWSDKRemoteTypeCompanion *shared __attribute__((swift_name("shared")));
- (id<RWSDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
- (id<RWSDKKotlinx_serialization_coreKSerializer>)serializerTypeParamsSerializers:(RWSDKKotlinArray<id<RWSDKKotlinx_serialization_coreKSerializer>> *)typeParamsSerializers __attribute__((swift_name("serializer(typeParamsSerializers:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("User")))
@interface RWSDKUser : RWSDKBase
- (instancetype)initWithEmail:(NSString *)email enableNotifications:(BOOL)enableNotifications id:(RWSDKInt * _Nullable)id name:(NSString *)name profilePicture:(NSString *)profilePicture pushId:(NSString * _Nullable)pushId userType:(RWSDKRemoteType * _Nullable)userType __attribute__((swift_name("init(email:enableNotifications:id:name:profilePicture:pushId:userType:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) RWSDKUserCompanion *companion __attribute__((swift_name("companion")));
- (RWSDKUser *)doCopyEmail:(NSString *)email enableNotifications:(BOOL)enableNotifications id:(RWSDKInt * _Nullable)id name:(NSString *)name profilePicture:(NSString *)profilePicture pushId:(NSString * _Nullable)pushId userType:(RWSDKRemoteType * _Nullable)userType __attribute__((swift_name("doCopy(email:enableNotifications:id:name:profilePicture:pushId:userType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="email")
*/
@property (readonly) NSString *email __attribute__((swift_name("email")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="enable_notifications")
*/
@property (readonly) BOOL enableNotifications __attribute__((swift_name("enableNotifications")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="id")
*/
@property (readonly) RWSDKInt * _Nullable id __attribute__((swift_name("id")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="name")
*/
@property (readonly) NSString *name __attribute__((swift_name("name")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="profile_picture")
*/
@property (readonly) NSString *profilePicture __attribute__((swift_name("profilePicture")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="push_id")
*/
@property (readonly) NSString * _Nullable pushId __attribute__((swift_name("pushId")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="user_type")
*/
@property (readonly) RWSDKRemoteType * _Nullable userType __attribute__((swift_name("userType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("User.Companion")))
@interface RWSDKUserCompanion : RWSDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) RWSDKUserCompanion *shared __attribute__((swift_name("shared")));
- (id<RWSDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserResponse")))
@interface RWSDKUserResponse : RWSDKBase
- (instancetype)initWithPostUrl:(RWSDKPostUrl *)postUrl readUrl:(NSString *)readUrl user:(RWSDKUser *)user __attribute__((swift_name("init(postUrl:readUrl:user:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) RWSDKUserResponseCompanion *companion __attribute__((swift_name("companion")));
- (RWSDKUserResponse *)doCopyPostUrl:(RWSDKPostUrl *)postUrl readUrl:(NSString *)readUrl user:(RWSDKUser *)user __attribute__((swift_name("doCopy(postUrl:readUrl:user:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="post_url")
*/
@property (readonly) RWSDKPostUrl *postUrl __attribute__((swift_name("postUrl")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="read_url")
*/
@property (readonly) NSString *readUrl __attribute__((swift_name("readUrl")));

/**
 * @note annotations
 *   kotlinx.serialization.SerialName(value="user")
*/
@property (readonly) RWSDKUser *user __attribute__((swift_name("user")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserResponse.Companion")))
@interface RWSDKUserResponseCompanion : RWSDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) RWSDKUserResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<RWSDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PictureData")))
@interface RWSDKPictureData : RWSDKBase
- (instancetype)initWithReadUrl:(NSString *)readUrl postUrl:(NSString *)postUrl key:(NSString *)key awsAccessKeyId:(NSString *)awsAccessKeyId policy:(NSString *)policy signature:(NSString *)signature __attribute__((swift_name("init(readUrl:postUrl:key:awsAccessKeyId:policy:signature:)"))) __attribute__((objc_designated_initializer));
- (RWSDKPictureData *)doCopyReadUrl:(NSString *)readUrl postUrl:(NSString *)postUrl key:(NSString *)key awsAccessKeyId:(NSString *)awsAccessKeyId policy:(NSString *)policy signature:(NSString *)signature __attribute__((swift_name("doCopy(readUrl:postUrl:key:awsAccessKeyId:policy:signature:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *awsAccessKeyId __attribute__((swift_name("awsAccessKeyId")));
@property (readonly) NSString *key __attribute__((swift_name("key")));
@property (readonly) NSString *policy __attribute__((swift_name("policy")));
@property (readonly) NSString *postUrl __attribute__((swift_name("postUrl")));
@property (readonly) NSString *readUrl __attribute__((swift_name("readUrl")));
@property (readonly) NSString *signature __attribute__((swift_name("signature")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Type")))
@interface RWSDKType : RWSDKKotlinEnum<RWSDKType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) RWSDKType *regular __attribute__((swift_name("regular")));
@property (class, readonly) RWSDKType *premium __attribute__((swift_name("premium")));
+ (RWSDKKotlinArray<RWSDKType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<RWSDKType *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserUi")))
@interface RWSDKUserUi : RWSDKBase
- (instancetype)initWithName:(NSString *)name email:(NSString *)email notificationsEnabled:(BOOL)notificationsEnabled pictureData:(RWSDKPictureData * _Nullable)pictureData type:(RWSDKType *)type pushId:(NSString * _Nullable)pushId isEmailVerified:(BOOL)isEmailVerified __attribute__((swift_name("init(name:email:notificationsEnabled:pictureData:type:pushId:isEmailVerified:)"))) __attribute__((objc_designated_initializer));
- (RWSDKUserUi *)doCopyName:(NSString *)name email:(NSString *)email notificationsEnabled:(BOOL)notificationsEnabled pictureData:(RWSDKPictureData * _Nullable)pictureData type:(RWSDKType *)type pushId:(NSString * _Nullable)pushId isEmailVerified:(BOOL)isEmailVerified __attribute__((swift_name("doCopy(name:email:notificationsEnabled:pictureData:type:pushId:isEmailVerified:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *email __attribute__((swift_name("email")));
@property (readonly) BOOL isEmailVerified __attribute__((swift_name("isEmailVerified")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) BOOL notificationsEnabled __attribute__((swift_name("notificationsEnabled")));
@property (readonly) RWSDKPictureData * _Nullable pictureData __attribute__((swift_name("pictureData")));
@property (readonly) NSString * _Nullable pushId __attribute__((swift_name("pushId")));
@property (readonly) RWSDKType *type __attribute__((swift_name("type")));
@end

__attribute__((swift_name("UiError")))
@interface RWSDKUiError : RWSDKKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (BOOL)isValid __attribute__((swift_name("isValid()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AllowedCharactersError")))
@interface RWSDKAllowedCharactersError : RWSDKUiError
- (instancetype)initWithValue:(NSString * _Nullable)value allowedChars:(NSString *)allowedChars __attribute__((swift_name("init(value:allowedChars:)"))) __attribute__((objc_designated_initializer));
- (RWSDKAllowedCharactersError *)doCopyValue:(NSString * _Nullable)value allowedChars:(NSString *)allowedChars __attribute__((swift_name("doCopy(value:allowedChars:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isValid __attribute__((swift_name("isValid()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EmptyValueError")))
@interface RWSDKEmptyValueError : RWSDKUiError
- (instancetype)initWithValue:(NSString * _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (RWSDKEmptyValueError *)doCopyValue:(NSString * _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isValid __attribute__((swift_name("isValid()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("InvalidEmailError")))
@interface RWSDKInvalidEmailError : RWSDKUiError
- (instancetype)initWithEmail:(NSString * _Nullable)email __attribute__((swift_name("init(email:)"))) __attribute__((objc_designated_initializer));
- (RWSDKInvalidEmailError *)doCopyEmail:(NSString * _Nullable)email __attribute__((swift_name("doCopy(email:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isValid __attribute__((swift_name("isValid()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MaximumSizeFieldError")))
@interface RWSDKMaximumSizeFieldError : RWSDKUiError
- (instancetype)initWithValue:(NSString * _Nullable)value maxValue:(int32_t)maxValue __attribute__((swift_name("init(value:maxValue:)"))) __attribute__((objc_designated_initializer));
- (RWSDKMaximumSizeFieldError *)doCopyValue:(NSString * _Nullable)value maxValue:(int32_t)maxValue __attribute__((swift_name("doCopy(value:maxValue:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isValid __attribute__((swift_name("isValid()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MinimumSizeFieldError")))
@interface RWSDKMinimumSizeFieldError : RWSDKUiError
- (instancetype)initWithValue:(NSString * _Nullable)value minimumSize:(int32_t)minimumSize __attribute__((swift_name("init(value:minimumSize:)"))) __attribute__((objc_designated_initializer));
- (RWSDKMinimumSizeFieldError *)doCopyValue:(NSString * _Nullable)value minimumSize:(int32_t)minimumSize __attribute__((swift_name("doCopy(value:minimumSize:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isValid __attribute__((swift_name("isValid()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NotNullObjectError")))
@interface RWSDKNotNullObjectError : RWSDKUiError
- (instancetype)initWithValue:(id _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (RWSDKNotNullObjectError *)doCopyValue:(id _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isValid __attribute__((swift_name("isValid()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SameValueError")))
@interface RWSDKSameValueError : RWSDKUiError
- (instancetype)initWithOriginalValue:(NSString *)originalValue value:(NSString * _Nullable)value __attribute__((swift_name("init(originalValue:value:)"))) __attribute__((objc_designated_initializer));
- (RWSDKSameValueError *)doCopyOriginalValue:(NSString *)originalValue value:(NSString * _Nullable)value __attribute__((swift_name("doCopy(originalValue:value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isValid __attribute__((swift_name("isValid()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("UiErrorValidator")))
@protocol RWSDKUiErrorValidator
@required
- (void)validate __attribute__((swift_name("validate()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EmailValidator")))
@interface RWSDKEmailValidator : RWSDKBase <RWSDKUiErrorValidator>
- (instancetype)initWithEmail:(NSString * _Nullable)email __attribute__((swift_name("init(email:)"))) __attribute__((objc_designated_initializer));
- (RWSDKEmailValidator *)doCopyEmail:(NSString * _Nullable)email __attribute__((swift_name("doCopy(email:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (void)validate __attribute__((swift_name("validate()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NameValidator")))
@interface RWSDKNameValidator : RWSDKBase <RWSDKUiErrorValidator>
- (instancetype)initWithName:(NSString * _Nullable)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (RWSDKNameValidator *)doCopyName:(NSString * _Nullable)name __attribute__((swift_name("doCopy(name:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (void)validate __attribute__((swift_name("validate()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PasswordValidator")))
@interface RWSDKPasswordValidator : RWSDKBase <RWSDKUiErrorValidator>
- (instancetype)initWithPassword:(NSString * _Nullable)password __attribute__((swift_name("init(password:)"))) __attribute__((objc_designated_initializer));
- (RWSDKPasswordValidator *)doCopyPassword:(NSString * _Nullable)password __attribute__((swift_name("doCopy(password:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (void)validate __attribute__((swift_name("validate()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SamePasswordValidator")))
@interface RWSDKSamePasswordValidator : RWSDKBase <RWSDKUiErrorValidator>
- (instancetype)initWithOriginalValue:(NSString * _Nullable)originalValue password:(NSString * _Nullable)password __attribute__((swift_name("init(originalValue:password:)"))) __attribute__((objc_designated_initializer));
- (RWSDKSamePasswordValidator *)doCopyOriginalValue:(NSString * _Nullable)originalValue password:(NSString * _Nullable)password __attribute__((swift_name("doCopy(originalValue:password:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (void)validate __attribute__((swift_name("validate()")));
@end

@interface RWSDKProfile (Extensions)
- (RWSDKUserResponse *)toUserRemote __attribute__((swift_name("toUserRemote()")));
- (RWSDKUserUi *)toUserUiIsEmailVerified:(BOOL)isEmailVerified __attribute__((swift_name("toUserUi(isEmailVerified:)")));
@end

@interface RWSDKLocalType (Extensions)
- (RWSDKRemoteType *)toRemoteType __attribute__((swift_name("toRemoteType()")));
- (RWSDKType *)toType __attribute__((swift_name("toType()")));
@end

@interface RWSDKRemoteType (Extensions)
- (RWSDKLocalType *)toLocalType __attribute__((swift_name("toLocalType()")));
- (RWSDKType *)toType __attribute__((swift_name("toType()")));
@end

@interface RWSDKUserResponse (Extensions)
- (RWSDKProfile *)toProfile __attribute__((swift_name("toProfile()")));
- (RWSDKUserUi *)toUserUiIsEmailVerified:(BOOL)isEmailVerified __attribute__((swift_name("toUserUi(isEmailVerified:)")));
@end

@interface RWSDKType (Extensions)
- (RWSDKLocalType *)toLocalType __attribute__((swift_name("toLocalType()")));
- (RWSDKRemoteType *)toRemoteType __attribute__((swift_name("toRemoteType()")));
@end

@interface RWSDKUserUi (Extensions)
- (RWSDKProfile *)toProfile __attribute__((swift_name("toProfile()")));
- (RWSDKUser *)toUserRemote __attribute__((swift_name("toUserRemote()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CoreModuleKt")))
@interface RWSDKCoreModuleKt : RWSDKBase
+ (NSArray<RWSDKKoin_coreModule *> *)appModules __attribute__((swift_name("appModules()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DataStoreSetup_iOSKt")))
@interface RWSDKDataStoreSetup_iOSKt : RWSDKBase
+ (id<RWSDKDatastore_coreDataStore>)createDataStore __attribute__((swift_name("createDataStore()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DataStoreSetupKt")))
@interface RWSDKDataStoreSetupKt : RWSDKBase
+ (id<RWSDKDatastore_coreDataStore>)getDataStoreProducePath:(NSString *(^)(void))producePath __attribute__((swift_name("getDataStore(producePath:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Platform_iosKt")))
@interface RWSDKPlatform_iosKt : RWSDKBase
+ (id<RWSDKPlatform>)getPlatform __attribute__((swift_name("getPlatform()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreKoin")))
@interface RWSDKKoin_coreKoin : RWSDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)close __attribute__((swift_name("close()")));
- (void)createEagerInstances __attribute__((swift_name("createEagerInstances()")));
- (RWSDKKoin_coreScope *)createScopeT:(id<RWSDKKoin_coreKoinScopeComponent>)t __attribute__((swift_name("createScope(t:)")));
- (RWSDKKoin_coreScope *)createScopeScopeId:(NSString *)scopeId __attribute__((swift_name("createScope(scopeId:)")));
- (RWSDKKoin_coreScope *)createScopeScopeId:(NSString *)scopeId source:(id _Nullable)source __attribute__((swift_name("createScope(scopeId:source:)")));
- (RWSDKKoin_coreScope *)createScopeScopeId:(NSString *)scopeId qualifier:(id<RWSDKKoin_coreQualifier>)qualifier source:(id _Nullable)source __attribute__((swift_name("createScope(scopeId:qualifier:source:)")));
- (void)declareInstance:(id _Nullable)instance qualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier secondaryTypes:(NSArray<id<RWSDKKotlinKClass>> *)secondaryTypes allowOverride:(BOOL)allowOverride __attribute__((swift_name("declare(instance:qualifier:secondaryTypes:allowOverride:)")));
- (void)deletePropertyKey:(NSString *)key __attribute__((swift_name("deleteProperty(key:)")));
- (void)deleteScopeScopeId:(NSString *)scopeId __attribute__((swift_name("deleteScope(scopeId:)")));
- (id)getQualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier parameters:(RWSDKKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("get(qualifier:parameters:)")));
- (id _Nullable)getClazz:(id<RWSDKKotlinKClass>)clazz qualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier parameters:(RWSDKKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("get(clazz:qualifier:parameters:)")));
- (NSArray<id> *)getAll __attribute__((swift_name("getAll()")));
- (RWSDKKoin_coreScope *)getOrCreateScopeScopeId:(NSString *)scopeId __attribute__((swift_name("getOrCreateScope(scopeId:)")));
- (RWSDKKoin_coreScope *)getOrCreateScopeScopeId:(NSString *)scopeId qualifier:(id<RWSDKKoin_coreQualifier>)qualifier source:(id _Nullable)source __attribute__((swift_name("getOrCreateScope(scopeId:qualifier:source:)")));
- (id _Nullable)getOrNullQualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier parameters:(RWSDKKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("getOrNull(qualifier:parameters:)")));
- (id _Nullable)getOrNullClazz:(id<RWSDKKotlinKClass>)clazz qualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier parameters:(RWSDKKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("getOrNull(clazz:qualifier:parameters:)")));
- (id _Nullable)getPropertyKey:(NSString *)key __attribute__((swift_name("getProperty(key:)")));
- (id)getPropertyKey:(NSString *)key defaultValue:(id)defaultValue __attribute__((swift_name("getProperty(key:defaultValue:)")));
- (RWSDKKoin_coreScope *)getScopeScopeId:(NSString *)scopeId __attribute__((swift_name("getScope(scopeId:)")));
- (RWSDKKoin_coreScope * _Nullable)getScopeOrNullScopeId:(NSString *)scopeId __attribute__((swift_name("getScopeOrNull(scopeId:)")));
- (id<RWSDKKotlinLazy>)injectQualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier mode:(RWSDKKotlinLazyThreadSafetyMode *)mode parameters:(RWSDKKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("inject(qualifier:mode:parameters:)")));
- (id<RWSDKKotlinLazy>)injectOrNullQualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier mode:(RWSDKKotlinLazyThreadSafetyMode *)mode parameters:(RWSDKKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("injectOrNull(qualifier:mode:parameters:)")));
- (void)loadModulesModules:(NSArray<RWSDKKoin_coreModule *> *)modules allowOverride:(BOOL)allowOverride createEagerInstances:(BOOL)createEagerInstances __attribute__((swift_name("loadModules(modules:allowOverride:createEagerInstances:)")));
- (void)setPropertyKey:(NSString *)key value:(id)value __attribute__((swift_name("setProperty(key:value:)")));
- (void)setupLoggerLogger:(RWSDKKoin_coreLogger *)logger __attribute__((swift_name("setupLogger(logger:)")));
- (void)unloadModulesModules:(NSArray<RWSDKKoin_coreModule *> *)modules __attribute__((swift_name("unloadModules(modules:)")));
@property (readonly) RWSDKKoin_coreExtensionManager *extensionManager __attribute__((swift_name("extensionManager")));
@property (readonly) RWSDKKoin_coreInstanceRegistry *instanceRegistry __attribute__((swift_name("instanceRegistry")));
@property (readonly) RWSDKKoin_coreLogger *logger __attribute__((swift_name("logger")));
@property (readonly) RWSDKKoin_corePropertyRegistry *propertyRegistry __attribute__((swift_name("propertyRegistry")));
@property (readonly) RWSDKKoin_coreScopeRegistry *scopeRegistry __attribute__((swift_name("scopeRegistry")));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface RWSDKKotlinRuntimeException : RWSDKKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface RWSDKKotlinIllegalStateException : RWSDKKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface RWSDKKotlinCancellationException : RWSDKKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(RWSDKKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol RWSDKKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<RWSDKKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((swift_name("Firebase_authAuthCredential")))
@interface RWSDKFirebase_authAuthCredential : RWSDKBase
- (instancetype)initWithIos:(FIRAuthCredential *)ios __attribute__((swift_name("init(ios:)"))) __attribute__((objc_designated_initializer));
@property (readonly) FIRAuthCredential *ios __attribute__((swift_name("ios")));
@property (readonly) NSString *providerId __attribute__((swift_name("providerId")));
@end

__attribute__((swift_name("RuntimeCloseable")))
@protocol RWSDKRuntimeCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end

__attribute__((swift_name("RuntimeSqlDriver")))
@protocol RWSDKRuntimeSqlDriver <RWSDKRuntimeCloseable>
@required
- (void)addListenerQueryKeys:(RWSDKKotlinArray<NSString *> *)queryKeys listener:(id<RWSDKRuntimeQueryListener>)listener __attribute__((swift_name("addListener(queryKeys:listener:)")));
- (RWSDKRuntimeTransacterTransaction * _Nullable)currentTransaction __attribute__((swift_name("currentTransaction()")));
- (id<RWSDKRuntimeQueryResult>)executeIdentifier:(RWSDKInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<RWSDKRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("execute(identifier:sql:parameters:binders:)")));
- (id<RWSDKRuntimeQueryResult>)executeQueryIdentifier:(RWSDKInt * _Nullable)identifier sql:(NSString *)sql mapper:(id<RWSDKRuntimeQueryResult> (^)(id<RWSDKRuntimeSqlCursor>))mapper parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<RWSDKRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("executeQuery(identifier:sql:mapper:parameters:binders:)")));
- (id<RWSDKRuntimeQueryResult>)doNewTransaction __attribute__((swift_name("doNewTransaction()")));
- (void)notifyListenersQueryKeys:(RWSDKKotlinArray<NSString *> *)queryKeys __attribute__((swift_name("notifyListeners(queryKeys:)")));
- (void)removeListenerQueryKeys:(RWSDKKotlinArray<NSString *> *)queryKeys listener:(id<RWSDKRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(queryKeys:listener:)")));
@end

__attribute__((swift_name("RuntimeTransactionCallbacks")))
@protocol RWSDKRuntimeTransactionCallbacks
@required
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));
@end

__attribute__((swift_name("RuntimeTransactionWithoutReturn")))
@protocol RWSDKRuntimeTransactionWithoutReturn <RWSDKRuntimeTransactionCallbacks>
@required
- (void)rollback __attribute__((swift_name("rollback()")));
- (void)transactionBody:(void (^)(id<RWSDKRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(body:)")));
@end

__attribute__((swift_name("RuntimeTransactionWithReturn")))
@protocol RWSDKRuntimeTransactionWithReturn <RWSDKRuntimeTransactionCallbacks>
@required
- (void)rollbackReturnValue:(id _Nullable)returnValue __attribute__((swift_name("rollback(returnValue:)")));
- (id _Nullable)transactionBody_:(id _Nullable (^)(id<RWSDKRuntimeTransactionWithReturn>))body __attribute__((swift_name("transaction(body_:)")));
@end

__attribute__((swift_name("RuntimeSqlSchema")))
@protocol RWSDKRuntimeSqlSchema
@required
- (id<RWSDKRuntimeQueryResult>)createDriver:(id<RWSDKRuntimeSqlDriver>)driver __attribute__((swift_name("create(driver:)")));
- (id<RWSDKRuntimeQueryResult>)migrateDriver:(id<RWSDKRuntimeSqlDriver>)driver oldVersion:(int64_t)oldVersion newVersion:(int64_t)newVersion callbacks:(RWSDKKotlinArray<RWSDKRuntimeAfterVersion *> *)callbacks __attribute__((swift_name("migrate(driver:oldVersion:newVersion:callbacks:)")));
@property (readonly) int64_t version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface RWSDKKotlinUnit : RWSDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) RWSDKKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("RuntimeTransacterTransaction")))
@interface RWSDKRuntimeTransacterTransaction : RWSDKBase <RWSDKRuntimeTransactionCallbacks>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id<RWSDKRuntimeQueryResult>)endTransactionSuccessful:(BOOL)successful __attribute__((swift_name("endTransaction(successful:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) RWSDKRuntimeTransacterTransaction * _Nullable enclosingTransaction __attribute__((swift_name("enclosingTransaction")));
@end

__attribute__((swift_name("RuntimeExecutableQuery")))
@interface RWSDKRuntimeExecutableQuery<__covariant RowType> : RWSDKBase
- (instancetype)initWithMapper:(RowType (^)(id<RWSDKRuntimeSqlCursor>))mapper __attribute__((swift_name("init(mapper:)"))) __attribute__((objc_designated_initializer));
- (id<RWSDKRuntimeQueryResult>)executeMapper:(id<RWSDKRuntimeQueryResult> (^)(id<RWSDKRuntimeSqlCursor>))mapper __attribute__((swift_name("execute(mapper:)")));
- (NSArray<RowType> *)executeAsList __attribute__((swift_name("executeAsList()")));
- (RowType)executeAsOne __attribute__((swift_name("executeAsOne()")));
- (RowType _Nullable)executeAsOneOrNull __attribute__((swift_name("executeAsOneOrNull()")));
@property (readonly) RowType (^mapper)(id<RWSDKRuntimeSqlCursor>) __attribute__((swift_name("mapper")));
@end

__attribute__((swift_name("RuntimeQuery")))
@interface RWSDKRuntimeQuery<__covariant RowType> : RWSDKRuntimeExecutableQuery<RowType>
- (instancetype)initWithMapper:(RowType (^)(id<RWSDKRuntimeSqlCursor>))mapper __attribute__((swift_name("init(mapper:)"))) __attribute__((objc_designated_initializer));
- (void)addListenerListener:(id<RWSDKRuntimeQueryListener>)listener __attribute__((swift_name("addListener(listener:)")));
- (void)removeListenerListener:(id<RWSDKRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(listener:)")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinCoroutineContext")))
@protocol RWSDKKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<RWSDKKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<RWSDKKotlinCoroutineContextElement> _Nullable)getKey:(id<RWSDKKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<RWSDKKotlinCoroutineContext>)minusKeyKey:(id<RWSDKKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<RWSDKKotlinCoroutineContext>)plusContext:(id<RWSDKKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol RWSDKKotlinCoroutineContextElement <RWSDKKotlinCoroutineContext>
@required
@property (readonly) id<RWSDKKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface RWSDKKotlinAbstractCoroutineContextElement : RWSDKBase <RWSDKKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<RWSDKKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<RWSDKKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol RWSDKKotlinContinuationInterceptor <RWSDKKotlinCoroutineContextElement>
@required
- (id<RWSDKKotlinContinuation>)interceptContinuationContinuation:(id<RWSDKKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<RWSDKKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface RWSDKKotlinx_coroutines_coreCoroutineDispatcher : RWSDKKotlinAbstractCoroutineContextElement <RWSDKKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<RWSDKKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) RWSDKKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<RWSDKKotlinCoroutineContext>)context block:(id<RWSDKKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));
- (void)dispatchYieldContext:(id<RWSDKKotlinCoroutineContext>)context block:(id<RWSDKKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<RWSDKKotlinContinuation>)interceptContinuationContinuation:(id<RWSDKKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<RWSDKKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)limitedParallelismParallelism:(int32_t)parallelism __attribute__((swift_name("limitedParallelism(parallelism:)")));
- (RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(RWSDKKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<RWSDKKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface RWSDKKotlinArray<T> : RWSDKBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(RWSDKInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<RWSDKKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol RWSDKKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<RWSDKKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<RWSDKKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol RWSDKKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<RWSDKKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<RWSDKKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol RWSDKKotlinx_serialization_coreKSerializer <RWSDKKotlinx_serialization_coreSerializationStrategy, RWSDKKotlinx_serialization_coreDeserializationStrategy>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface RWSDKKotlinEnumCompanion : RWSDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) RWSDKKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreModule")))
@interface RWSDKKoin_coreModule : RWSDKBase
- (instancetype)initWith_createdAtStart:(BOOL)_createdAtStart __attribute__((swift_name("init(_createdAtStart:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (RWSDKKoin_coreKoinDefinition<id> *)factoryQualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier definition:(id _Nullable (^)(RWSDKKoin_coreScope *, RWSDKKoin_coreParametersHolder *))definition __attribute__((swift_name("factory(qualifier:definition:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (void)includesModule:(RWSDKKotlinArray<RWSDKKoin_coreModule *> *)module __attribute__((swift_name("includes(module:)")));
- (void)includesModule_:(id)module __attribute__((swift_name("includes(module_:)")));
- (void)indexPrimaryTypeInstanceFactory:(RWSDKKoin_coreInstanceFactory<id> *)instanceFactory __attribute__((swift_name("indexPrimaryType(instanceFactory:)")));
- (void)indexSecondaryTypesInstanceFactory:(RWSDKKoin_coreInstanceFactory<id> *)instanceFactory __attribute__((swift_name("indexSecondaryTypes(instanceFactory:)")));
- (NSArray<RWSDKKoin_coreModule *> *)plusModules:(NSArray<RWSDKKoin_coreModule *> *)modules __attribute__((swift_name("plus(modules:)")));
- (NSArray<RWSDKKoin_coreModule *> *)plusModule:(RWSDKKoin_coreModule *)module __attribute__((swift_name("plus(module:)")));
- (void)prepareForCreationAtStartInstanceFactory:(RWSDKKoin_coreSingleInstanceFactory<id> *)instanceFactory __attribute__((swift_name("prepareForCreationAtStart(instanceFactory:)")));
- (void)scopeScopeSet:(void (^)(RWSDKKoin_coreScopeDSL *))scopeSet __attribute__((swift_name("scope(scopeSet:)")));
- (void)scopeQualifier:(id<RWSDKKoin_coreQualifier>)qualifier scopeSet:(void (^)(RWSDKKoin_coreScopeDSL *))scopeSet __attribute__((swift_name("scope(qualifier:scopeSet:)")));
- (RWSDKKoin_coreKoinDefinition<id> *)singleQualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier createdAtStart:(BOOL)createdAtStart definition:(id _Nullable (^)(RWSDKKoin_coreScope *, RWSDKKoin_coreParametersHolder *))definition __attribute__((swift_name("single(qualifier:createdAtStart:definition:)")));
@property (readonly) RWSDKMutableSet<RWSDKKoin_coreSingleInstanceFactory<id> *> *eagerInstances __attribute__((swift_name("eagerInstances")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSMutableArray<RWSDKKoin_coreModule *> *includedModules __attribute__((swift_name("includedModules")));
@property (readonly) BOOL isLoaded __attribute__((swift_name("isLoaded")));
@property (readonly) RWSDKMutableDictionary<NSString *, RWSDKKoin_coreInstanceFactory<id> *> *mappings __attribute__((swift_name("mappings")));
@end

__attribute__((swift_name("Datastore_coreDataStore")))
@protocol RWSDKDatastore_coreDataStore
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)updateDataTransform:(id<RWSDKKotlinSuspendFunction1>)transform completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("updateData(transform:completionHandler:)")));
@property (readonly) id<RWSDKKotlinx_coroutines_coreFlow> data __attribute__((swift_name("data")));
@end

__attribute__((swift_name("Koin_coreLockable")))
@interface RWSDKKoin_coreLockable : RWSDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreScope")))
@interface RWSDKKoin_coreScope : RWSDKKoin_coreLockable
- (instancetype)initWithScopeQualifier:(id<RWSDKKoin_coreQualifier>)scopeQualifier id:(NSString *)id isRoot:(BOOL)isRoot _koin:(RWSDKKoin_coreKoin *)_koin __attribute__((swift_name("init(scopeQualifier:id:isRoot:_koin:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)close __attribute__((swift_name("close()")));
- (void)declareInstance:(id _Nullable)instance qualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier secondaryTypes:(NSArray<id<RWSDKKotlinKClass>> *)secondaryTypes allowOverride:(BOOL)allowOverride __attribute__((swift_name("declare(instance:qualifier:secondaryTypes:allowOverride:)")));
- (id)getQualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier parameters:(RWSDKKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("get(qualifier:parameters:)")));
- (id _Nullable)getClazz:(id<RWSDKKotlinKClass>)clazz qualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier parameters:(RWSDKKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("get(clazz:qualifier:parameters:)")));
- (NSArray<id> *)getAll __attribute__((swift_name("getAll()")));
- (NSArray<id> *)getAllClazz:(id<RWSDKKotlinKClass>)clazz __attribute__((swift_name("getAll(clazz:)")));
- (RWSDKKoin_coreKoin *)getKoin __attribute__((swift_name("getKoin()")));
- (id _Nullable)getOrNullQualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier parameters:(RWSDKKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("getOrNull(qualifier:parameters:)")));
- (id _Nullable)getOrNullClazz:(id<RWSDKKotlinKClass>)clazz qualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier parameters:(RWSDKKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("getOrNull(clazz:qualifier:parameters:)")));
- (id)getPropertyKey:(NSString *)key __attribute__((swift_name("getProperty(key:)")));
- (id)getPropertyKey:(NSString *)key defaultValue:(id)defaultValue __attribute__((swift_name("getProperty(key:defaultValue:)")));
- (id _Nullable)getPropertyOrNullKey:(NSString *)key __attribute__((swift_name("getPropertyOrNull(key:)")));
- (RWSDKKoin_coreScope *)getScopeScopeID:(NSString *)scopeID __attribute__((swift_name("getScope(scopeID:)")));
- (id _Nullable)getSource __attribute__((swift_name("getSource()")));
- (id<RWSDKKotlinLazy>)injectQualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier mode:(RWSDKKotlinLazyThreadSafetyMode *)mode parameters:(RWSDKKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("inject(qualifier:mode:parameters:)")));
- (id<RWSDKKotlinLazy>)injectOrNullQualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier mode:(RWSDKKotlinLazyThreadSafetyMode *)mode parameters:(RWSDKKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("injectOrNull(qualifier:mode:parameters:)")));
- (BOOL)isNotClosed __attribute__((swift_name("isNotClosed()")));
- (void)linkToScopes:(RWSDKKotlinArray<RWSDKKoin_coreScope *> *)scopes __attribute__((swift_name("linkTo(scopes:)")));
- (void)registerCallbackCallback:(id<RWSDKKoin_coreScopeCallback>)callback __attribute__((swift_name("registerCallback(callback:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (void)unlinkScopes:(RWSDKKotlinArray<RWSDKKoin_coreScope *> *)scopes __attribute__((swift_name("unlink(scopes:)")));
@property (readonly) RWSDKStately_concurrencyThreadLocalRef<NSMutableArray<RWSDKKoin_coreParametersHolder *> *> *_parameterStackLocal __attribute__((swift_name("_parameterStackLocal")));
@property id _Nullable _source __attribute__((swift_name("_source")));
@property (readonly) BOOL closed __attribute__((swift_name("closed")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) BOOL isRoot __attribute__((swift_name("isRoot")));
@property (readonly) RWSDKKoin_coreLogger *logger __attribute__((swift_name("logger")));
@property (readonly) id<RWSDKKoin_coreQualifier> scopeQualifier __attribute__((swift_name("scopeQualifier")));
@end

__attribute__((swift_name("Koin_coreKoinScopeComponent")))
@protocol RWSDKKoin_coreKoinScopeComponent <RWSDKKoin_coreKoinComponent>
@required
- (void)closeScope __attribute__((swift_name("closeScope()"))) __attribute__((deprecated("not used internaly anymore")));
@property (readonly) RWSDKKoin_coreScope *scope __attribute__((swift_name("scope")));
@end

__attribute__((swift_name("Koin_coreQualifier")))
@protocol RWSDKKoin_coreQualifier
@required
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol RWSDKKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol RWSDKKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol RWSDKKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol RWSDKKotlinKClass <RWSDKKotlinKDeclarationContainer, RWSDKKotlinKAnnotatedElement, RWSDKKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((swift_name("Koin_coreParametersHolder")))
@interface RWSDKKoin_coreParametersHolder : RWSDKBase
- (instancetype)initWith_values:(NSMutableArray<id> *)_values useIndexedValues:(RWSDKBoolean * _Nullable)useIndexedValues __attribute__((swift_name("init(_values:useIndexedValues:)"))) __attribute__((objc_designated_initializer));
- (RWSDKKoin_coreParametersHolder *)addValue:(id)value __attribute__((swift_name("add(value:)")));
- (id _Nullable)component1 __attribute__((swift_name("component1()")));
- (id _Nullable)component2 __attribute__((swift_name("component2()")));
- (id _Nullable)component3 __attribute__((swift_name("component3()")));
- (id _Nullable)component4 __attribute__((swift_name("component4()")));
- (id _Nullable)component5 __attribute__((swift_name("component5()")));
- (id _Nullable)elementAtI:(int32_t)i clazz:(id<RWSDKKotlinKClass>)clazz __attribute__((swift_name("elementAt(i:clazz:)")));
- (id)get __attribute__((swift_name("get()")));
- (id _Nullable)getI:(int32_t)i __attribute__((swift_name("get(i:)")));
- (id _Nullable)getOrNull __attribute__((swift_name("getOrNull()")));
- (id _Nullable)getOrNullClazz:(id<RWSDKKotlinKClass>)clazz __attribute__((swift_name("getOrNull(clazz:)")));
- (RWSDKKoin_coreParametersHolder *)insertIndex:(int32_t)index value:(id)value __attribute__((swift_name("insert(index:value:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (BOOL)isNotEmpty __attribute__((swift_name("isNotEmpty()")));
- (void)setI:(int32_t)i t:(id _Nullable)t __attribute__((swift_name("set(i:t:)")));
- (int32_t)size __attribute__((swift_name("size()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int32_t index __attribute__((swift_name("index")));
@property (readonly) RWSDKBoolean * _Nullable useIndexedValues __attribute__((swift_name("useIndexedValues")));
@property (readonly) NSArray<id> *values __attribute__((swift_name("values")));
@end

__attribute__((swift_name("KotlinLazy")))
@protocol RWSDKKotlinLazy
@required
- (BOOL)isInitialized __attribute__((swift_name("isInitialized()")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinLazyThreadSafetyMode")))
@interface RWSDKKotlinLazyThreadSafetyMode : RWSDKKotlinEnum<RWSDKKotlinLazyThreadSafetyMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) RWSDKKotlinLazyThreadSafetyMode *synchronized __attribute__((swift_name("synchronized")));
@property (class, readonly) RWSDKKotlinLazyThreadSafetyMode *publication __attribute__((swift_name("publication")));
@property (class, readonly) RWSDKKotlinLazyThreadSafetyMode *none __attribute__((swift_name("none")));
+ (RWSDKKotlinArray<RWSDKKotlinLazyThreadSafetyMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<RWSDKKotlinLazyThreadSafetyMode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("Koin_coreLogger")))
@interface RWSDKKoin_coreLogger : RWSDKBase
- (instancetype)initWithLevel:(RWSDKKoin_coreLevel *)level __attribute__((swift_name("init(level:)"))) __attribute__((objc_designated_initializer));
- (void)debugMsg:(NSString *)msg __attribute__((swift_name("debug(msg:)")));
- (void)displayLevel:(RWSDKKoin_coreLevel *)level msg:(NSString *)msg __attribute__((swift_name("display(level:msg:)")));
- (void)errorMsg:(NSString *)msg __attribute__((swift_name("error(msg:)")));
- (void)infoMsg:(NSString *)msg __attribute__((swift_name("info(msg:)")));
- (BOOL)isAtLvl:(RWSDKKoin_coreLevel *)lvl __attribute__((swift_name("isAt(lvl:)")));
- (void)logLvl:(RWSDKKoin_coreLevel *)lvl msg:(NSString *(^)(void))msg __attribute__((swift_name("log(lvl:msg:)")));
- (void)logLvl:(RWSDKKoin_coreLevel *)lvl msg_:(NSString *)msg __attribute__((swift_name("log(lvl:msg_:)")));
- (void)warnMsg:(NSString *)msg __attribute__((swift_name("warn(msg:)")));
@property RWSDKKoin_coreLevel *level __attribute__((swift_name("level")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreExtensionManager")))
@interface RWSDKKoin_coreExtensionManager : RWSDKBase
- (instancetype)initWith_koin:(RWSDKKoin_coreKoin *)_koin __attribute__((swift_name("init(_koin:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (id<RWSDKKoin_coreKoinExtension>)getExtensionId:(NSString *)id __attribute__((swift_name("getExtension(id:)")));
- (id<RWSDKKoin_coreKoinExtension> _Nullable)getExtensionOrNullId:(NSString *)id __attribute__((swift_name("getExtensionOrNull(id:)")));
- (void)registerExtensionId:(NSString *)id extension:(id<RWSDKKoin_coreKoinExtension>)extension __attribute__((swift_name("registerExtension(id:extension:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreInstanceRegistry")))
@interface RWSDKKoin_coreInstanceRegistry : RWSDKBase
- (instancetype)initWith_koin:(RWSDKKoin_coreKoin *)_koin __attribute__((swift_name("init(_koin:)"))) __attribute__((objc_designated_initializer));
- (void)saveMappingAllowOverride:(BOOL)allowOverride mapping:(NSString *)mapping factory:(RWSDKKoin_coreInstanceFactory<id> *)factory logWarning:(BOOL)logWarning __attribute__((swift_name("saveMapping(allowOverride:mapping:factory:logWarning:)")));
- (int32_t)size __attribute__((swift_name("size()")));
@property (readonly) RWSDKKoin_coreKoin *_koin __attribute__((swift_name("_koin")));
@property (readonly) NSDictionary<NSString *, RWSDKKoin_coreInstanceFactory<id> *> *instances __attribute__((swift_name("instances")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_corePropertyRegistry")))
@interface RWSDKKoin_corePropertyRegistry : RWSDKBase
- (instancetype)initWith_koin:(RWSDKKoin_coreKoin *)_koin __attribute__((swift_name("init(_koin:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (void)deletePropertyKey:(NSString *)key __attribute__((swift_name("deleteProperty(key:)")));
- (id _Nullable)getPropertyKey:(NSString *)key __attribute__((swift_name("getProperty(key:)")));
- (void)savePropertiesProperties:(NSDictionary<NSString *, id> *)properties __attribute__((swift_name("saveProperties(properties:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreScopeRegistry")))
@interface RWSDKKoin_coreScopeRegistry : RWSDKBase
- (instancetype)initWith_koin:(RWSDKKoin_coreKoin *)_koin __attribute__((swift_name("init(_koin:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) RWSDKKoin_coreScopeRegistryCompanion *companion __attribute__((swift_name("companion")));
- (void)loadScopesModules:(NSSet<RWSDKKoin_coreModule *> *)modules __attribute__((swift_name("loadScopes(modules:)")));
@property (readonly) RWSDKKoin_coreScope *rootScope __attribute__((swift_name("rootScope")));
@property (readonly) NSSet<id<RWSDKKoin_coreQualifier>> *scopeDefinitions __attribute__((swift_name("scopeDefinitions")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol RWSDKKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((swift_name("RuntimeQueryListener")))
@protocol RWSDKRuntimeQueryListener
@required
- (void)queryResultsChanged __attribute__((swift_name("queryResultsChanged()")));
@end

__attribute__((swift_name("RuntimeQueryResult")))
@protocol RWSDKRuntimeQueryResult
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("await(completionHandler:)")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("RuntimeSqlPreparedStatement")))
@protocol RWSDKRuntimeSqlPreparedStatement
@required
- (void)bindBooleanIndex:(int32_t)index boolean:(RWSDKBoolean * _Nullable)boolean __attribute__((swift_name("bindBoolean(index:boolean:)")));
- (void)bindBytesIndex:(int32_t)index bytes:(RWSDKKotlinByteArray * _Nullable)bytes __attribute__((swift_name("bindBytes(index:bytes:)")));
- (void)bindDoubleIndex:(int32_t)index double:(RWSDKDouble * _Nullable)double_ __attribute__((swift_name("bindDouble(index:double:)")));
- (void)bindLongIndex:(int32_t)index long:(RWSDKLong * _Nullable)long_ __attribute__((swift_name("bindLong(index:long:)")));
- (void)bindStringIndex:(int32_t)index string:(NSString * _Nullable)string __attribute__((swift_name("bindString(index:string:)")));
@end

__attribute__((swift_name("RuntimeSqlCursor")))
@protocol RWSDKRuntimeSqlCursor
@required
- (RWSDKBoolean * _Nullable)getBooleanIndex:(int32_t)index __attribute__((swift_name("getBoolean(index:)")));
- (RWSDKKotlinByteArray * _Nullable)getBytesIndex:(int32_t)index __attribute__((swift_name("getBytes(index:)")));
- (RWSDKDouble * _Nullable)getDoubleIndex:(int32_t)index __attribute__((swift_name("getDouble(index:)")));
- (RWSDKLong * _Nullable)getLongIndex:(int32_t)index __attribute__((swift_name("getLong(index:)")));
- (NSString * _Nullable)getStringIndex:(int32_t)index __attribute__((swift_name("getString(index:)")));
- (id<RWSDKRuntimeQueryResult>)next __attribute__((swift_name("next()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RuntimeAfterVersion")))
@interface RWSDKRuntimeAfterVersion : RWSDKBase
- (instancetype)initWithAfterVersion:(int64_t)afterVersion block:(void (^)(id<RWSDKRuntimeSqlDriver>))block __attribute__((swift_name("init(afterVersion:block:)"))) __attribute__((objc_designated_initializer));
@property (readonly) int64_t afterVersion __attribute__((swift_name("afterVersion")));
@property (readonly) void (^block)(id<RWSDKRuntimeSqlDriver>) __attribute__((swift_name("block")));
@end

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol RWSDKKotlinCoroutineContextKey
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuation")))
@protocol RWSDKKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<RWSDKKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface RWSDKKotlinAbstractCoroutineContextKey<B, E> : RWSDKBase <RWSDKKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<RWSDKKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<RWSDKKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface RWSDKKotlinx_coroutines_coreCoroutineDispatcherKey : RWSDKKotlinAbstractCoroutineContextKey<id<RWSDKKotlinContinuationInterceptor>, RWSDKKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<RWSDKKotlinCoroutineContextKey>)baseKey safeCast:(id<RWSDKKotlinCoroutineContextElement> _Nullable (^)(id<RWSDKKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) RWSDKKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol RWSDKKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol RWSDKKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol RWSDKKotlinx_serialization_coreEncoder
@required
- (id<RWSDKKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<RWSDKKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<RWSDKKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<RWSDKKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<RWSDKKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) RWSDKKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol RWSDKKotlinx_serialization_coreSerialDescriptor
@required

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSArray<id<RWSDKKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<RWSDKKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSArray<id<RWSDKKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) RWSDKKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol RWSDKKotlinx_serialization_coreDecoder
@required
- (id<RWSDKKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<RWSDKKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (RWSDKKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<RWSDKKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<RWSDKKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) RWSDKKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreKoinDefinition")))
@interface RWSDKKoin_coreKoinDefinition<R> : RWSDKBase
- (instancetype)initWithModule:(RWSDKKoin_coreModule *)module factory:(RWSDKKoin_coreInstanceFactory<R> *)factory __attribute__((swift_name("init(module:factory:)"))) __attribute__((objc_designated_initializer));
- (RWSDKKoin_coreKoinDefinition<R> *)doCopyModule:(RWSDKKoin_coreModule *)module factory:(RWSDKKoin_coreInstanceFactory<R> *)factory __attribute__((swift_name("doCopy(module:factory:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) RWSDKKoin_coreInstanceFactory<R> *factory __attribute__((swift_name("factory")));
@property (readonly) RWSDKKoin_coreModule *module __attribute__((swift_name("module")));
@end

__attribute__((swift_name("Koin_coreInstanceFactory")))
@interface RWSDKKoin_coreInstanceFactory<T> : RWSDKKoin_coreLockable
- (instancetype)initWithBeanDefinition:(RWSDKKoin_coreBeanDefinition<T> *)beanDefinition __attribute__((swift_name("init(beanDefinition:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) RWSDKKoin_coreInstanceFactoryCompanion *companion __attribute__((swift_name("companion")));
- (T _Nullable)createContext:(RWSDKKoin_coreInstanceContext *)context __attribute__((swift_name("create(context:)")));
- (void)dropScope:(RWSDKKoin_coreScope * _Nullable)scope __attribute__((swift_name("drop(scope:)")));
- (void)dropAll __attribute__((swift_name("dropAll()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (T _Nullable)getContext:(RWSDKKoin_coreInstanceContext *)context __attribute__((swift_name("get(context:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isCreatedContext:(RWSDKKoin_coreInstanceContext * _Nullable)context __attribute__((swift_name("isCreated(context:)")));
@property (readonly) RWSDKKoin_coreBeanDefinition<T> *beanDefinition __attribute__((swift_name("beanDefinition")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreSingleInstanceFactory")))
@interface RWSDKKoin_coreSingleInstanceFactory<T> : RWSDKKoin_coreInstanceFactory<T>
- (instancetype)initWithBeanDefinition:(RWSDKKoin_coreBeanDefinition<T> *)beanDefinition __attribute__((swift_name("init(beanDefinition:)"))) __attribute__((objc_designated_initializer));
- (T _Nullable)createContext:(RWSDKKoin_coreInstanceContext *)context __attribute__((swift_name("create(context:)")));
- (void)dropScope:(RWSDKKoin_coreScope * _Nullable)scope __attribute__((swift_name("drop(scope:)")));
- (void)dropAll __attribute__((swift_name("dropAll()")));
- (T _Nullable)getContext:(RWSDKKoin_coreInstanceContext *)context __attribute__((swift_name("get(context:)")));
- (BOOL)isCreatedContext:(RWSDKKoin_coreInstanceContext * _Nullable)context __attribute__((swift_name("isCreated(context:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreScopeDSL")))
@interface RWSDKKoin_coreScopeDSL : RWSDKBase
- (instancetype)initWithScopeQualifier:(id<RWSDKKoin_coreQualifier>)scopeQualifier module:(RWSDKKoin_coreModule *)module __attribute__((swift_name("init(scopeQualifier:module:)"))) __attribute__((objc_designated_initializer));
- (RWSDKKoin_coreKoinDefinition<id> *)factoryQualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier definition:(id _Nullable (^)(RWSDKKoin_coreScope *, RWSDKKoin_coreParametersHolder *))definition __attribute__((swift_name("factory(qualifier:definition:)")));
- (RWSDKKoin_coreKoinDefinition<id> *)scopedQualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier definition:(id _Nullable (^)(RWSDKKoin_coreScope *, RWSDKKoin_coreParametersHolder *))definition __attribute__((swift_name("scoped(qualifier:definition:)")));
@property (readonly) RWSDKKoin_coreModule *module __attribute__((swift_name("module")));
@property (readonly) id<RWSDKKoin_coreQualifier> scopeQualifier __attribute__((swift_name("scopeQualifier")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol RWSDKKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol RWSDKKotlinSuspendFunction1 <RWSDKKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:completionHandler:)")));
@end

__attribute__((swift_name("Koin_coreScopeCallback")))
@protocol RWSDKKoin_coreScopeCallback
@required
- (void)onScopeCloseScope:(RWSDKKoin_coreScope *)scope __attribute__((swift_name("onScopeClose(scope:)")));
@end

__attribute__((swift_name("Stately_concurrencyThreadLocalRef")))
@interface RWSDKStately_concurrencyThreadLocalRef<T> : RWSDKBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (T _Nullable)get __attribute__((swift_name("get()")));
- (void)remove __attribute__((swift_name("remove()")));
- (void)setValue:(T _Nullable)value __attribute__((swift_name("set(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreLevel")))
@interface RWSDKKoin_coreLevel : RWSDKKotlinEnum<RWSDKKoin_coreLevel *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) RWSDKKoin_coreLevel *debug __attribute__((swift_name("debug")));
@property (class, readonly) RWSDKKoin_coreLevel *info __attribute__((swift_name("info")));
@property (class, readonly) RWSDKKoin_coreLevel *warning __attribute__((swift_name("warning")));
@property (class, readonly) RWSDKKoin_coreLevel *error __attribute__((swift_name("error")));
@property (class, readonly) RWSDKKoin_coreLevel *none __attribute__((swift_name("none")));
+ (RWSDKKotlinArray<RWSDKKoin_coreLevel *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<RWSDKKoin_coreLevel *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("Koin_coreKoinExtension")))
@protocol RWSDKKoin_coreKoinExtension
@required
- (void)onClose __attribute__((swift_name("onClose()")));
@property RWSDKKoin_coreKoin *koin __attribute__((swift_name("koin")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreScopeRegistry.Companion")))
@interface RWSDKKoin_coreScopeRegistryCompanion : RWSDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) RWSDKKoin_coreScopeRegistryCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface RWSDKKotlinByteArray : RWSDKBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(RWSDKByte *(^)(RWSDKInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (RWSDKKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol RWSDKKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<RWSDKKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<RWSDKKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<RWSDKKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) RWSDKKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface RWSDKKotlinx_serialization_coreSerializersModule : RWSDKBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<RWSDKKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<RWSDKKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<RWSDKKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<RWSDKKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<RWSDKKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<RWSDKKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<RWSDKKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<RWSDKKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol RWSDKKotlinAnnotation
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface RWSDKKotlinx_serialization_coreSerialKind : RWSDKBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol RWSDKKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<RWSDKKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<RWSDKKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<RWSDKKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<RWSDKKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) RWSDKKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface RWSDKKotlinNothing : RWSDKBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreBeanDefinition")))
@interface RWSDKKoin_coreBeanDefinition<T> : RWSDKBase
- (instancetype)initWithScopeQualifier:(id<RWSDKKoin_coreQualifier>)scopeQualifier primaryType:(id<RWSDKKotlinKClass>)primaryType qualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier definition:(T _Nullable (^)(RWSDKKoin_coreScope *, RWSDKKoin_coreParametersHolder *))definition kind:(RWSDKKoin_coreKind *)kind secondaryTypes:(NSArray<id<RWSDKKotlinKClass>> *)secondaryTypes __attribute__((swift_name("init(scopeQualifier:primaryType:qualifier:definition:kind:secondaryTypes:)"))) __attribute__((objc_designated_initializer));
- (RWSDKKoin_coreBeanDefinition<T> *)doCopyScopeQualifier:(id<RWSDKKoin_coreQualifier>)scopeQualifier primaryType:(id<RWSDKKotlinKClass>)primaryType qualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier definition:(T _Nullable (^)(RWSDKKoin_coreScope *, RWSDKKoin_coreParametersHolder *))definition kind:(RWSDKKoin_coreKind *)kind secondaryTypes:(NSArray<id<RWSDKKotlinKClass>> *)secondaryTypes __attribute__((swift_name("doCopy(scopeQualifier:primaryType:qualifier:definition:kind:secondaryTypes:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (BOOL)hasTypeClazz:(id<RWSDKKotlinKClass>)clazz __attribute__((swift_name("hasType(clazz:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isClazz:(id<RWSDKKotlinKClass>)clazz qualifier:(id<RWSDKKoin_coreQualifier> _Nullable)qualifier scopeDefinition:(id<RWSDKKoin_coreQualifier>)scopeDefinition __attribute__((swift_name("is(clazz:qualifier:scopeDefinition:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property RWSDKKoin_coreCallbacks<T> *callbacks __attribute__((swift_name("callbacks")));
@property (readonly) T _Nullable (^definition)(RWSDKKoin_coreScope *, RWSDKKoin_coreParametersHolder *) __attribute__((swift_name("definition")));
@property (readonly) RWSDKKoin_coreKind *kind __attribute__((swift_name("kind")));
@property (readonly) id<RWSDKKotlinKClass> primaryType __attribute__((swift_name("primaryType")));
@property id<RWSDKKoin_coreQualifier> _Nullable qualifier __attribute__((swift_name("qualifier")));
@property (readonly) id<RWSDKKoin_coreQualifier> scopeQualifier __attribute__((swift_name("scopeQualifier")));
@property NSArray<id<RWSDKKotlinKClass>> *secondaryTypes __attribute__((swift_name("secondaryTypes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreInstanceFactoryCompanion")))
@interface RWSDKKoin_coreInstanceFactoryCompanion : RWSDKBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) RWSDKKoin_coreInstanceFactoryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *ERROR_SEPARATOR __attribute__((swift_name("ERROR_SEPARATOR")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreInstanceContext")))
@interface RWSDKKoin_coreInstanceContext : RWSDKBase
- (instancetype)initWithLogger:(RWSDKKoin_coreLogger *)logger scope:(RWSDKKoin_coreScope *)scope parameters:(RWSDKKoin_coreParametersHolder * _Nullable)parameters __attribute__((swift_name("init(logger:scope:parameters:)"))) __attribute__((objc_designated_initializer));
@property (readonly) RWSDKKoin_coreLogger *logger __attribute__((swift_name("logger")));
@property (readonly) RWSDKKoin_coreParametersHolder * _Nullable parameters __attribute__((swift_name("parameters")));
@property (readonly) RWSDKKoin_coreScope *scope __attribute__((swift_name("scope")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface RWSDKKotlinByteIterator : RWSDKBase <RWSDKKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (RWSDKByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol RWSDKKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<RWSDKKotlinKClass>)kClass provider:(id<RWSDKKotlinx_serialization_coreKSerializer> (^)(NSArray<id<RWSDKKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<RWSDKKotlinKClass>)kClass serializer:(id<RWSDKKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<RWSDKKotlinKClass>)baseClass actualClass:(id<RWSDKKotlinKClass>)actualClass actualSerializer:(id<RWSDKKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<RWSDKKotlinKClass>)baseClass defaultDeserializerProvider:(id<RWSDKKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<RWSDKKotlinKClass>)baseClass defaultDeserializerProvider:(id<RWSDKKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<RWSDKKotlinKClass>)baseClass defaultSerializerProvider:(id<RWSDKKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreKind")))
@interface RWSDKKoin_coreKind : RWSDKKotlinEnum<RWSDKKoin_coreKind *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) RWSDKKoin_coreKind *singleton __attribute__((swift_name("singleton")));
@property (class, readonly) RWSDKKoin_coreKind *factory __attribute__((swift_name("factory")));
@property (class, readonly) RWSDKKoin_coreKind *scoped __attribute__((swift_name("scoped")));
+ (RWSDKKotlinArray<RWSDKKoin_coreKind *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<RWSDKKoin_coreKind *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreCallbacks")))
@interface RWSDKKoin_coreCallbacks<T> : RWSDKBase
- (instancetype)initWithOnClose:(void (^ _Nullable)(T _Nullable))onClose __attribute__((swift_name("init(onClose:)"))) __attribute__((objc_designated_initializer));
- (RWSDKKoin_coreCallbacks<T> *)doCopyOnClose:(void (^ _Nullable)(T _Nullable))onClose __attribute__((swift_name("doCopy(onClose:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) void (^ _Nullable onClose)(T _Nullable) __attribute__((swift_name("onClose")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
